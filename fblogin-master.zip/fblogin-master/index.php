<!DOCTYPE HTML>
 
<html>
 
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Facebook login</title>
    </head>
 
    <body>
 
        <a href="https://www.facebook.com/dialog/oauth?client_id=509011619175617&redirect_uri=http://localhost/fblogin/callback.php&scope=public_profile"><img src="facebook-sign-in.png"/></a>
 
    </body>
 
</html>